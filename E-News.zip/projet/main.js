// nav background change on scroll
let header = document.querySelector("header");

window.addEventListener("scroll",()=>{
    header.classList.toggle("shadow", window.scrollY > 0)
})

//filter 
$(document).ready(function(){
    $(".filter-item").click(function(){
      const value = $(this).attr("data-filter");
      if (value == "all"){
        $(".post-box").show("1000");
      }else{
        $(".post-box")
        .not("." + value)
        .hide("1000");
        $(".post-box")
        .filtre("." + value)
        .show("1000");
       }
    });
    $(".filter-item").click(function(){
        $(this).addClass("active-filter").siblings().removeClass("active-filtre");
    });
});

document.addEventListener("DOMContentLoaded", function() {
  // Vérifier si l'utilisateur est connecté en utilisant le cookie "isLoggedIn"
  var isLoggedIn = document.cookie.includes;

  var loginBtn = document.querySelector(".login");
  var signupBtn = document.querySelector(".signup");
  var profile = document.createElement("div");
  profile.classList.add("profile-info");
  profile.textContent = "Profil de l'utilisateur";

  // Récupérer le nom d'utilisateur à partir de l'URL
  var urlParams = new URLSearchParams(window.location.search);
  var userName = urlParams.get("user");

  if (isLoggedIn && userName) {
    // Si l'utilisateur est connecté et le nom d'utilisateur est présent dans l'URL, masquer les boutons de connexion et afficher le profil avec le nom d'utilisateur
    loginBtn.style.display = "none";
    signupBtn.style.display = "none";
    profile.textContent = "Profil de l'utilisateur: " + userName;

    // Ajouter du style au profil
    profile.style.color = "white"; // Couleur du texte
    profile.style.backgroundColor = "blue"; // Couleur de fond
    profile.style.padding = "10px"; // Rembourrage

    // Créer un bouton de déconnexion
    var logoutBtn = document.createElement("a");
    logoutBtn.classList.add("logout");
    logoutBtn.textContent = "Déconnexion";
    logoutBtn.href = "accueil.html";

    // Ajouter le bouton de déconnexion et le profil à la navigation
    var rightNav = document.querySelector(".right-nav");
    rightNav.appendChild(profile);
    rightNav.appendChild(logoutBtn);
  } else {
    // Si l'utilisateur n'est pas connecté ou le nom d'utilisateur est manquant dans l'URL, afficher les boutons de connexion et masquer le profil
    loginBtn.style.display = "block";
    signupBtn.style.display = "block";
    var profileInfo = document.querySelector(".profile-info");
    if (profileInfo) {
      profileInfo.remove();
    }
  }

  // Rediriger vers la page de déconnexion
  logoutBtn.addEventListener("click", function() {
    document.cookie = "isLoggedIn=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;"; // Supprimer le cookie isLoggedIn
    history.replaceState(null, "", "accueil.html"); // Rediriger vers la page de déconnexion
  });
});


 
