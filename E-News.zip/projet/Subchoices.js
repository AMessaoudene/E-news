function changeButtonColor(button) {
  button.style.backgroundColor = 'red';
  button.style.color = 'white';
}