<?php
// Database connection configuration
$servername = 'localhost';
$username = 'root';
$password = '';
$dbname = 'user';

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize error message variable
$errorMsg = "";

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $email = $_POST["email"];
    $password = $_POST["password"];

    // Query to check if the user exists in the database
    $sql = "SELECT * FROM users WHERE email = '$email' AND password = '$password'";
    $result = $conn->query($sql);

    if ($result->num_rows == 1) {
        // User exists, login successful
        $row = $result->fetch_assoc();
        $userName = $row["name"];
        // Set a cookie to indicate that the user is logged in
        setcookie("isLoggedIn", true, time() + (86400 * 30), "/"); // Cookie valid for 30 days

        // Redirect to a success page or perform any desired action
        // For example, you can redirect to a dashboard page:
        header("Location: accueil.html?user=" . urlencode($userName));
        exit();
    } else {
        // Invalid login credentials
        $errorMsg = "Invalid email or password";
    }
}

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Validated Login Form</title>
	<link rel="stylesheet" href="LOGIN1.css">
	<link rel="icon" href="logo.PNG" type="image/x-icon">
</head>
<body>
	<div class="container">
		<h1 class="label">User Login</h1>
		<form class="login_form" action="http://localhost/projet/LOGIN1.php" method="post">
			<div class="font">Email or Phone</div>
			<input autocomplete="off" type="text" name="email">
			<div id="email_error">Please fill up your Email or Phone</div>
			<div class="font font2">Password</div>
			<input type="password" name="password">
			<span style="color: red;"><?php echo $errorMsg; ?></span><br><br>
			<div id="pass_error">Please fill up your Password</div>
			<button type="submit">Login</button>
		</form>
	</div>	
	<script src="LOGIN1.js"></script>
</body>
</html>