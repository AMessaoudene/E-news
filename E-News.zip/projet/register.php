<?php
// Database connection configuration
$servername = 'localhost';
$username = 'root';
$password = '';
$dbname = 'user';

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] === "POST"){
    // Get form data
    $name = $_POST["name"];
    $surname = $_POST["surname"];
    $middleName = $_POST["middle-name"];
    $email = $_POST["email"];
    $password = $_POST["password"];
    $phoneNumber = $_POST["Phone_number"];
    $dateOfBirth = $_POST["date"];
    $gender = $_POST["gender"];
    $newsletter = isset($_POST["newsletter"]) ? 1 : 0;

    // Insert user data into the database
    $sql = "INSERT INTO users (name, surname, middle_name, email, password, phone_number, date_of_birth, gender, newsletter)
            VALUES ('$name', '$surname', '$middleName', '$email', '$password', '$phoneNumber', '$dateOfBirth', '$gender', $newsletter)";

    if ($conn->query($sql) === TRUE) {
        // Successful registration
        echo "Account created successfully!";
        // Redirect to login page
        header("Location: accueil.html");
        exit();
    } else {
        // Error occurred during registration
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Close the database connection
$conn->close();
?>